#!/bin/bash

# Function to display the user information:
displayUserInfo() {
    echo "Username: $(whoami)"
    echo "User ID: $(id -u)"
    echo "Group ID: $(id -g)"
    echo "Home Directory: $HOME"
    echo "Shell: $SHELL"
}

# Call the displayUserInfo function to display the user information:
displayUserInfo
