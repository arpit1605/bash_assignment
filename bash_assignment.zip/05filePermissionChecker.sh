#!/bin/bash

file=$1

# Check whether the file exists or not:
if [ -f "$FILE" ]; then
    echo "File does not exist."
    exit 1
fi

# Check the read permissions:
if [ -r "$file" ]; then
    echo "The file has read permission."
else
    echo "The file does not have read permission."
fi

# Check the write permissions:
if [ -w "$file" ]; then
    echo "The file has write permission."
else
    echo "The file does not have write permission."
fi

# Check the execute permissions:
if [ -x "$file" ]; then
    echo "The file has execute permission."
else
    echo "The file does not have execute permission."
fi
