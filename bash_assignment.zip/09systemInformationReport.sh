#!/bin/bash

REPORT_FILE="system_report.txt"

# Get the system uptime:
UPTIME=$(uptime -p)

# Get the memory_usage usage:
MEMORY_USAGE=$(free -h)

# Get the CPU load:
CPU_USAGE=$(top -bn1 | grep "load average:" | awk '{print $10 $11 $12}' | sed 's/,//g')

# Get the disk usage:
DISK_USAGE=$(df /| grep /| awk '{print $5}')

# Get the top 15 running processes with respect to the memory usage:
PROCESSES=$(ps aux --sort=-%mem | head -n 16)

echo "*********************************************************** System Information Report **********************************************************" > $REPORT_FILE
echo " " >> $REPORT_FILE

echo "System Uptime:" >> $REPORT_FILE
echo "$UPTIME" >> $REPORT_FILE
echo " " >> $REPORT_FILE

echo "Memory Usage:" >> $REPORT_FILE
echo "$MEMORY_USAGE" >> $REPORT_FILE
echo " " >> $REPORT_FILE

echo "CPU Usage:" >> $REPORT_FILE
echo "$CPU_USAGE" >> $REPORT_FILE
echo " " >> $REPORT_FILE

echo "Disk Usage:" >> $REPORT_FILE
echo "$DISK_USAGE" >> $REPORT_FILE
echo " " >> $REPORT_FILE

echo "Top 15 Running processes (sorted by higher memory usage):" >> $REPORT_FILE
echo "$PROCESSES" >> $REPORT_FILE
echo " " >> $REPORT_FILE
echo "************************************************************************************************************************************************" >> $REPORT_FILE

# Print message to indicate completion:
echo "System report generated and saved to $REPORT_FILE"
