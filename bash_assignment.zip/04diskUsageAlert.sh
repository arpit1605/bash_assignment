#!/bin/bash

# Set the threshold for disk usage to 80%:
THRESHOLD_VAL=80

# Check disk usage of the root filesystem:
DISK_USAGE=$(df / | grep / | awk '{ print $5 }' | sed 's/%//g')

# Check if usage is above the threshold_value:
if [ "$DISK_USAGE" -gt "$THRESHOLD_VAL" ]; then
    # Replace with the actual email address:
    RECIPIENT_EMAIL="arpit_agr0123@yahoo.com"
    SUBJECT="Disk Usage Alert: / is at ${DISK_USAGE}%"
    BODY="Warning: The disk usage of the root filesystem (/) is at ${DISK_USAGE}%. Please take necessary steps to free space."
    # Send an alert via email:
    echo "$BODY" | mail -s "$SUBJECT" "$RECIPIENT_EMAIL"
fi
