#!/bin/bash

# Seting the process name and log file variables:
PROCESS_NAME="apache2"
LOG_FILE="/var/log/process_monitor.log"

# Check whether the process is running or not:
if pgrep "$PROCESS_NAME" > /dev/null; then
    echo "$(date): The process $PROCESS_NAME is running." >> "$LOG_FILE"
else
    echo "$(date): The process $PROCESS_NAME is not running."
    echo "Starting the process $PROCESS_NAME." >> "$LOG_FILE"
    # Starting the process:
    systemctl start "$PROCESS_NAME"
    # Check whether the process started successfully or not:
    if [ $? -eq 0 ]; then
        echo "$(date): The process $PROCESS_NAME started successfully." >> "$LOG_FILE"
    else
        echo "$(date): Failed to start the process: $PROCESS_NAME." >> "$LOG_FILE"
    fi
fi
