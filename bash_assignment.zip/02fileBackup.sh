#!/bin/bash

# Retrieve the directory provided as an argument:
SRC_DIR="$1"

# Check whether the source directory exists or not:
if [ ! -d "$SRC_DIR" ]; then
    echo "The source directory $SRC_DIR does not exist!"
    exit 1
fi

# Create the backup directory with a timestamp:
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BKP_DIR="${SRC_DIR}/backup_${TIMESTAMP}"
mkdir "$BKP_DIR"

# Copy all the .txt files to the backup directory:
cp "$SRC_DIR"/*.txt "$BKP_DIR"

# Check whether the copy operation was successful or not:
if [ $? -eq 0 ]; then
    echo "The backup process is completed and placed at the location: $BKP_DIR"
else
    echo "The backup process is failed!"
    exit 1
fi
