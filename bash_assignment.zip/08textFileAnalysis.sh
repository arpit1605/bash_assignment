#!/bin/bash

file=$1

# Check whether the file exists or not:
if [ ! -e "$file" ]; then
    echo "The input file does not exists!"
    exit 1
fi

# Count the number of lines, words, and characters:
lineCount=$(wc -l < "$file")
wordCount=$(wc -w < "$file")
characterCount=$(wc -m < "$file")

# Display the file count statistics:
echo "***** File Statistics *****"
echo "No of Lines       : $lineCount"
echo "No of Words       : $wordCount"
echo "No of Characters  : $characterCount"
