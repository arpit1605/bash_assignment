#!/bin/bash

# Set the base directory:
DIR="/home/user"

# Create the directory structure:
mkdir "$DIR/projects"
mkdir "$DIR/projects/project"{1,2,3}
mkdir "$DIR/documents"
mkdir "$DIR/downloads"
echo "The directory structure has been created successfully."

