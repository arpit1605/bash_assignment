#!/bin/bash

# Function to perform the user desired operation:
calculate() {
    case $operator in
        +)
            result=$(echo "$num1 + $num2" | bc)
            ;;
        -)
            result=$(echo "$num1 - $num2" | bc)
            ;;
        \*)
            result=$(echo "$num1 * $num2" | bc)
            ;;
        /)
            if [ "$num2" -eq 0 ]; then
                echo "Divide by 0 Error!!!"
                exit 1
            else
	        result=$(echo "$num1 / $num2" | bc)
	    fi
            ;;
        *)
            echo "Invalid operator. Please use one of +, -, *, /."
            exit 1
            ;;
    esac
    echo "The resultant value is: $result"
}

# Prompt the user for input 2 numbers and the operator:
read -p "Enter the first number: " num1
read -p "Enter the second number: " num2
read -p "Enter the operation you wish to perform (+, -, *, /): " operator

# Call the calculate function:
calculate
