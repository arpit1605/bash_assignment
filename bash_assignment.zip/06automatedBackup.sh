#!/bin/bash

# Define the source and destination directories:
SRC_DIR="/home/user/documents"
BKP_DIR="/home/user/backup"
# Define the backup file name:
BKP_FILE="documents_backup.tar.gz"

# Create a backup directory if it doesn't exist:
mkdir "$BKP_DIR"

# Compress the source directory into a tarball:
tar -cvzf "$BKP_FILE" -C "$SRC_DIR" .

# Move the backup file into the backup directory:
mv "$BKP_FILE" "$BKP_DIR"

# Check if the tarball was created successfully:
if [ $? -eq 0 ]; then
    echo "The backup process is compeleted and the backup file is placed at: $BKP_DIR/$BKP_FILE"
else
    echo "The backup process has failed!"
    exit 1
fi

